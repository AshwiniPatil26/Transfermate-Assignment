<?php

function getDirContents( $dir, &$results = [] ) {
	$files = scandir( $dir );

	foreach( $files as $key => $value ) {
		$path = realpath( $dir . DIRECTORY_SEPARATOR . $value );
		if( !is_dir( $path ) ) {
			$results[] = $path;
		} else {
			if( $value != "." && $value != ".." ) {
				getDirContents( $path, $results );
				$results[] = $path;
			}
		}
	}

	return $results;
}

$xmlFiles = getDirContents( '/xampp/htdocs/WORK' );

foreach( $xmlFiles as $xmlfile ) {

	$xmlfiledata = file_get_contents( $xmlfile );
	$new         = simplexml_load_string( $xmlfiledata );
	$con         = json_encode( $new );
	$data        = json_decode( $con, true );
	$data        = prepare_data( $data );

	insert_into_database( $data );

	function insert_into_database( $data ) {
		$count = 0;

		foreach( $data as $author => $books ) {
			$count++;

			insert_author( $count, $author );

			foreach( $books as $book ) {
				insert_book( $count, $book );
			}
		}

	}

	function prepare_data( $newArr ) {
		$var = [];
		foreach( $newArr as $arr ) {
			foreach( $arr as $book ) {
				if( !array_key_exists( $book['author'], $var ) ) {
					$var[$book['author']] = [];
				}
				array_push( $var[$book['author']], $book['name'] );
			}

			return $var;

		}
	}

	function insert_author( $id, $author_name ) {
		// EXPECTED DATA STRUCTURE
		//		CREATE TABLE authors(
		//			id INT GENERATED ALWAYS AS IDENTITY,
		//          author_name VARCHAR(255) NOT NULL,
		//          PRIMARY KEY(id)
		//       );

		$db_query = 'INSERT INTO authors(author_id, author_name) VALUES($id, $author_name)';
		print( $db_query );
	}

	function insert_book( $author_id, $book_name ) {
	// EXPECTED DATA STRUCTURE
	//		CREATE TABLE books(
	//			id INT GENERATED ALWAYS AS IDENTITY,
	//          author_id INT,
	//          book_name VARCHAR(255) NOT NULL,
	//          PRIMARY KEY(id),
	//          CONSTRAINT fk_author
	//              FOREIGN KEY(author_id)
	//	                REFERENCES author(id)
	//        );

		$db_query = 'INSERT INTO books(author_id, book_name) VALUES($author_id, $book_name)';
		print( $db_query );
	}

}
